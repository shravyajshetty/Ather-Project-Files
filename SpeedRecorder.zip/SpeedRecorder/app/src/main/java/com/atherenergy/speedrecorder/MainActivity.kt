package com.atherenergy.speedrecorder

import android.content.ClipData
import android.content.ClipDescription
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.*
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.constraintlayout.motion.widget.MotionLayout
import androidx.constraintlayout.widget.ConstraintLayout
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(),OnMapReadyCallback{
    private lateinit var mapView: MapView;
    private lateinit var  googleMap: GoogleMap;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN



        mapView= findViewById(R.id.map);
        mapView.onCreate(null)
        mapView.onResume()
        mapView.getMapAsync(this)

        iv_speed2.setOnDragListener(dragListeneer)
        iv_speed.setOnDragListener(dragListeneer)

        iv_speed2.setOnLongClickListener{
            val clipText= "ClipData Text"
            val item = ClipData.Item(clipText)
            val myTypes= arrayOf(ClipDescription.MIMETYPE_TEXT_PLAIN)
            val data =ClipData(clipText,myTypes,item)
            val dragShadowBuilder = View.DragShadowBuilder(it)
            it.startDragAndDrop(data,dragShadowBuilder,it,0)
        }


    }

    val dragListeneer = View.OnDragListener{view,event->
        when(event.action) {
            DragEvent.ACTION_DRAG_STARTED -> {
                event.clipDescription.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)

            }
            DragEvent.ACTION_DRAG_ENTERED->{
                view.invalidate()
                true
            }
            DragEvent.ACTION_DRAG_LOCATION->true
            DragEvent.ACTION_DRAG_EXITED-> {
                view.invalidate()
                true
            }
            DragEvent.ACTION_DROP->{
                val item = event.clipData.getItemAt(0)
                val v = event.localState as View
                val owner = v.parent as ViewGroup
                owner.removeView(v)
                val destination = view as ImageView
                destination.rootView
                v.visibility = View.VISIBLE
                true;
            }
            DragEvent.ACTION_DRAG_ENDED->{
                view.invalidate()
                true


            }
            else ->false
        }

    }



    override fun onMapReady(p0: GoogleMap) {
        val latitude = 37.422160
        val longitude = -122.084270
        val zoomLevel = 15f
        val homeLatLng = LatLng(latitude, longitude)
        MapsInitializer.initialize(applicationContext)
        googleMap= p0
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(homeLatLng, zoomLevel))
        googleMap.addMarker(MarkerOptions().position(homeLatLng))

    }
}